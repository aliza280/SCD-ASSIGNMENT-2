from pydantic import BaseModel, EmailStr
from typing import Optional

# Pydantic schema for user-related operations
class UserBase(BaseModel):
    email: EmailStr  # Use EmailStr for email validation
    password: str  # Plain password (will be hashed later)

# Schema for creating a user (register)
class UserCreate(UserBase):
    password: str  # For user registration, plain password is needed

# Schema for reading a user (API response)
class UserRead(UserBase):
    id: int  # User ID (read-only)

    class Config:
        orm_mode = True  # Allow SQLAlchemy models to be converted to Pydantic models

# Schema for updating a user (e.g., password change)
class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    password: Optional[str] = None

    class Config:
        orm_mode = True  # Allow SQLAlchemy models to be converted to Pydantic models
