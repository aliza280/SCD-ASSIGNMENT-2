from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from app.database import SessionLocal, engine
from app import models, schemas, crud, auth
from app.config import settings

# Initialize FastAPI app
app = FastAPI()

# Create tables in the database
models.Base.metadata.create_all(bind=engine)

# Set up templates and static files
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")


# Dependency to get the database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Routes for Authentication
@app.get("/register")
def register_form(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})


@app.post("/register")
async def register(request: Request, db: Session = Depends(get_db)):
    form = await request.form()
    email = form.get("email")
    password = form.get("password")
    confirm_password = form.get("confirm_password")

    # Handle registration logic (password match, email check, etc.)
    if password != confirm_password:
        flash("Passwords do not match", "error")
        return RedirectResponse(url="/register", status_code=303)

    user = crud.create_user(db=db, email=email, password=password)
    flash("Registration successful! Please log in.", "success")
    return RedirectResponse(url="/login", status_code=303)


@app.get("/login")
def login_form(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


@app.post("/login")
async def login(request: Request, db: Session = Depends(get_db)):
    form = await request.form()
    email = form.get("email")
    password = form.get("password")

    # Validate login credentials
    user = crud.authenticate_user(db=db, email=email, password=password)
    if user is None:
        flash("Invalid email or password", "error")
        return RedirectResponse(url="/login", status_code=303)

    # Start session for logged-in user (use cookies, session management)
    response = RedirectResponse(url="/dashboard")
    response.set_cookie(key="user_id", value=str(user.id), httponly=True)
    return response


@app.get("/logout")
def logout(request: Request):
    response = RedirectResponse(url="/login")
    response.delete_cookie("user_id")
    flash("You have been logged out", "success")
    return response


# Routes for Task Management
@app.get("/dashboard")
def dashboard(request: Request, db: Session = Depends(get_db)):
    user_id = get_current_user_id(request)
    tasks = crud.get_tasks_by_user(db=db, user_id=user_id)
    return templates.TemplateResponse("dashboard.html", {"request": request, "tasks": tasks})


@app.get("/tasks/add")
def task_form(request: Request):
    return templates.TemplateResponse("task_form.html", {"request": request})


@app.post("/tasks/add")
async def create_task(request: Request, db: Session = Depends(get_db)):
    form = await request.form()
    title = form.get("title")
    description = form.get("description")

    user_id = get_current_user_id(request)
    crud.create_task(db=db, user_id=user_id, title=title, description=description)
    flash("Task created successfully", "success")
    return RedirectResponse(url="/dashboard", status_code=303)


@app.get("/tasks/edit/{task_id}")
def edit_task_form(request: Request, task_id: int, db: Session = Depends(get_db)):
    task = crud.get_task_by_id(db=db, task_id=task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return templates.TemplateResponse("task_form.html", {"request": request, "task": task})


@app.post("/tasks/edit/{task_id}")
async def update_task(request: Request, task_id: int, db: Session = Depends(get_db)):
    form = await request.form()
    title = form.get("title")
    description = form.get("description")

    task = crud.update_task(db=db, task_id=task_id, title=title, description=description)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")

    flash("Task updated successfully", "success")
    return RedirectResponse(url="/dashboard", status_code=303)


@app.get("/tasks/delete/{task_id}")
def delete_task(task_id: int, db: Session = Depends(get_db)):
    task = crud.delete_task(db=db, task_id=task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")

    flash("Task deleted successfully", "success")
    return RedirectResponse(url="/dashboard", status_code=303)


# Utility functions
def get_current_user_id(request: Request):
    # Assuming we store the user ID in a cookie after login
    user_id = request.cookies.get("user_id")
    if not user_id:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return int(user_id)
