from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base  # Import Base from your database setup file

class Task(Base):
    __tablename__ = "tasks"  # Table name in the database

    id = Column(Integer, primary_key=True, index=True)  # Primary key for the task
    title = Column(String, index=True)  # Task title
    description = Column(String)  # Task description
    user_id = Column(Integer, ForeignKey("users.id"))  # Foreign key linking to the user (User.id)

    # Establish a relationship to the User model
    owner = relationship("User", back_populates="tasks")  # 'tasks' on User model should match 'owner' here

    def __repr__(self):
        return f"<Task(id={self.id}, title={self.title}, description={self.description})>"

