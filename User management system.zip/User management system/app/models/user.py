from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import relationship
from app.database import Base  # Import Base from your database setup file

class User(Base):
    __tablename__ = "users"  # Table name for users

    id = Column(Integer, primary_key=True, index=True)  # Primary key for the user
    email = Column(String, unique=True, index=True)  # User's email (unique)
    hashed_password = Column(String)  # Hashed password for secure storage

    # Define the relationship to the Task model
    tasks = relationship("Task", back_populates="owner")  # 'owner' in Task must match 'tasks' here

    def __repr__(self):
        return f"<User(id={self.id}, email={self.email})>"
