from fastapi import APIRouter, HTTPException, Depends, status
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models import Task, User
from app.utils import get_current_user_from_cookie, get_current_user_from_token
from fastapi.security import OAuth2PasswordBearer

router = APIRouter()

# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# For API JWT authentication
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="api/login")

# Create a new task (Web)
@router.post("/tasks/add")
async def add_task(title: str, description: str, db: Session = Depends(get_db), user: User = Depends(get_current_user_from_cookie)):
    task = Task(title=title, description=description, user_id=user.id)
    db.add(task)
    db.commit()
    db.refresh(task)
    return RedirectResponse("/dashboard", status_code=303)

# Create a new task (API)
@router.post("/api/tasks")
async def add_task_api(title: str, description: str, db: Session = Depends(get_db), user: User = Depends(get_current_user_from_token)):
    task = Task(title=title, description=description, user_id=user.id)
    db.add(task)
    db.commit()
    db.refresh(task)
    return {"id": task.id, "title": task.title, "description": task.description}

# View all tasks (Web)
@router.get("/dashboard")
async def get_tasks(db: Session = Depends(get_db), user: User = Depends(get_current_user_from_cookie)):
    tasks = db.query(Task).filter(Task.user_id == user.id).all()
    return {"tasks": tasks}

# View all tasks (API)
@router.get("/api/tasks")
async def get_tasks_api(db: Session = Depends(get_db), user: User = Depends(get_current_user_from_token)):
    tasks = db.query(Task).filter(Task.user_id == user.id).all()
    return {"tasks": tasks}

# Edit a task (Web)
@router.post("/tasks/edit/{task_id}")
async def edit_task(task_id: int, title: str, description: str, db: Session = Depends(get_db), user: User = Depends(get_current_user_from_cookie)):
    task = db.query(Task).filter(Task.id == task_id, Task.user_id == user.id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    task.title = title
    task.description = description
    db.commit()
    return RedirectResponse("/dashboard", status_code=303)

# Edit a task (API)
@router.put("/api/tasks/{task_id}")
async def edit_task_api(task_id: int, title: str, description: str, db: Session = Depends(get_db), user: User = Depends(get_current_user_from_token)):
    task = db.query(Task).filter(Task.id == task_id, Task.user_id == user.id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    task.title = title
    task.description = description
    db.commit()
    return {"message": "Task updated successfully"}

# Delete a task (Web)
@router.post("/tasks/delete/{task_id}")
async def delete_task(task_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user_from_cookie)):
    task = db.query(Task).filter(Task.id == task_id, Task.user_id == user.id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    db.delete(task)
    db.commit()
    return RedirectResponse("/dashboard", status_code=303)

# Delete a task (API)
@router.delete("/api/tasks/{task_id}")
async def delete_task_api(task_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user_from_token)):
    task = db.query(Task).filter(Task.id == task_id, Task.user_id == user.id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    db.delete(task)
    db.commit()
    return {"message": "Task deleted successfully"}
